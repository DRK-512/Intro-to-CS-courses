/*  

* Name: Darek Konopka     
* Date: 5/5/2021
* Question number: 1
* Description: In this code we will do the following:

1) add some strings to Stack
2) use search method from stack Java class to get the position of an element in the stack
3) get the top element in the stack
4) pop elements from stack

*/

  
import java.util.*;
import Stack.*; 
  
public class LabExcercise {
    public static void main(String args[])   {
    
        // Creating an empty Stack
        Stack astack = new Stack();
  
        // Use push() to add elements into the Stack
        astack.push("A");
        astack.push("B");
        astack.push("C");
        astack.push("D");
        
        // Displaying the Stack
        int position = astack.search("C");
        System.out.println("Position of C is: " + astack);
        
        // Pop each element
        while(!astack.empty()){
        System.out.println(astack.pop());
        }
        
        
    }
}