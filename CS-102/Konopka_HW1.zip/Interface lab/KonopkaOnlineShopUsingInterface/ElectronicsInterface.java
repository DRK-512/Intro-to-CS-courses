package KonopkaOnlineShopUsingInterface;

public interface ElectronicsInterface extends ProductInterface {
 
 public String getManufacturer();
 
}