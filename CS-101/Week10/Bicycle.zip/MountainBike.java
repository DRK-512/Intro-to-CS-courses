/* MountainBike class, a subclass of the Bicycle class 
   - modified from an example on the Oracle's Java Documentation
   Yao Xu
*/

public class MountainBike extends Bicycle 
{   
    // one added field:
    private String suspension;
    
    // one constructor:
    public MountainBike( int startGear,
                         int startCadence,
                         int startSpeed,
                         String suspensionType )
    {
        super( startGear, startCadence, startSpeed );
        this.setSuspension( suspensionType );
    }
    
    // accessor method:
    public String getSuspension( )
    {
        return this.suspension;
    }

    // mutator method:
    public void setSuspension( String suspensionType ) 
    {
        this.suspension = suspensionType;
    }
    
    // override the toString method from Bicycle
    @Override
    public String toString( ) 
    {
        return super.toString( )
               + "\nThe MountainBike has a "
               + getSuspension( ) + " suspension.";
    }
} 