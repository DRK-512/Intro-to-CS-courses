/* Bicycle class 
   - modified from an example on the Oracle's Java Documentation
   Yao Xu
*/

public class Bicycle 
{        
    // the Bicycle class has three fields:
    private int gear;
    private int cadence;
    private int speed; 
        
    // one constructor:
    public Bicycle( int startGear, int startCadence, int startSpeed ) 
    {
        gear = startGear;
        cadence = startCadence;
        speed = startSpeed;
    }
    
    // accessor methods:
    public int getGear( ) 
    {
        return this.gear;
    }
    
    public int getCadence( ) 
    {
        return this.cadence;
    }
        
    public int getSpeed( ) 
    {
        return this.speed;
    }
    
    // mutator methods:
    public void setGear( int gear ) 
    {
        this.gear = gear;
    }
    
    public void setCadence( int cadence ) 
    {
        this.cadence = cadence;
    }
        
    public void getSpeed( int speed ) 
    {
        this.speed = speed;
    }
    
    // overriding toString method
    @Override
    public String toString( )
    {
        return "Bike is in gear " + this.gear
               + " with a cadence of " + this.cadence
               + " and travelling at a speed of " + this.speed + ".";
    }
            
}