/* RoadBike class, a subclass of the Bicycle class 
   - modified from an example on the Oracle's Java Documentation
   Yao Xu
*/

public class RoadBike extends Bicycle
{
    // one added field:
    private int tireWidth; // In millimeters (mm)
    
    // one constructor:
    public RoadBike( int startGear,
                     int startCadence,
                     int startSpeed,
                     int newTireWidth)
    {
        super( startGear, startCadence, startSpeed );
        this.setTireWidth( newTireWidth );
    }
    
    // accessor method:
    public int getTireWidth( )
    {
        return this.tireWidth;
    }
    
    // mutator method:
    public void setTireWidth( int tireWidth )
    {
        this.tireWidth = tireWidth;
    }
    
    // override the toString method from Bicycle
    @Override
    public String toString( )
    {
        return super.toString( )
               + "\nThe RoadBike has " 
               + getTireWidth( ) + " MM tires.";
    }
}